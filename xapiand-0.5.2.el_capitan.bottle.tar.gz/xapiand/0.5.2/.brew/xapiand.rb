class Xapiand < Formula
  desc "Xapiand: A RESTful Search Engine"
  homepage "https://kronuz.io/Xapiand"
  url "https://github.com/Kronuz/Xapiand/archive/v0.5.2.tar.gz"
  sha256 "2b44f681da563537649620db1dd183f9ad1292a649302bd0a93c8108bf54524a"
  head "https://github.com/Kronuz/Xapiand.git"

  depends_on "cmake" => :build
  depends_on "pkg-config" => :build
  depends_on "llvm@5" => :build
  depends_on "xapian"

  def install
    mkdir "build" do
      args = std_cmake_args + %W[
        -DCMAKE_C_COMPILER=#{Formula["llvm@5"].opt_bin}/clang
        -DCMAKE_CXX_COMPILER=#{Formula["llvm@5"].opt_bin}/clang++
      ]
      system "cmake", "..", "-DCCACHE_FOUND=CCACHE_FOUND-NOTFOUND", *args
      system "make"
      system "install_name_tool", "-change", "#{Formula["llvm@5"].opt_lib}/libc++.1.dylib", "/usr/lib/libc++.1.dylib", "bin/xapiand"
      system "make", "install"
    end
  end

  test do
    system bin/"xapiand", "--version"
  end
end
